const utils = require("./../common/utils");
const userPasscode = utils.createHex(`123456`);
console.log(userPasscode);
