# Surer Fi Node

Run backend server

```
npm install
npm start
```
